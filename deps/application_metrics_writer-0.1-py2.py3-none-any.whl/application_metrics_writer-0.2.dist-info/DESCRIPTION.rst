teps to build the python Package
Run the below command

$ python setup.py bdist_wheel --universal
After the build, The python package will be created in "dist" directory.


